#pragma once
#include "Instruction.h"
using namespace std;

class MagicArray: public Instruction {
public:
    int size;
    double a[110];
    MagicArray(): size(0) {}
    MagicArray(int n): size(n) {};
    double& operator[](int i) {
        return a[i];
    }

    void apply(std::vector<int> &vec) {
        for (int i = 0; i < size; i++)
        vec[i] += int(a[i]);
    }
    void apply(std::vector<double> &vec) {
        for (int i = 0; i < size; i++)
        vec[i] += a[i];
    }
    void output() {
        
    }
};