#pragma once

void action(Animal* animal, std::vector<Dog> & dogzone, std::vector<Bird> & birdzone) {

    Dog* dog = dynamic_cast<Dog*>(animal);

    std::cout << dog << " " << &dog << std::endl;

    std::cout << *animal << " " << animal << " " << &animal << std::endl;

    dogzone.push_back(*std::move(dog));

}