#pragma once

class Part{
    int id;
public:
    Part();
    Part(int);
    int& get();
};