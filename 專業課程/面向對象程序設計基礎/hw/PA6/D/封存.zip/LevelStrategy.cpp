#include "LevelStrategy.h"

int P1LStrategy::getBase() {
    return 2000;
}

int P2LStrategy::getBase() {
    return 5000;
}

int P3LStrategy::getBase() {
    return 10000;
}