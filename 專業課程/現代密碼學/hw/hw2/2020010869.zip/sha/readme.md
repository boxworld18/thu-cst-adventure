# SHA3-256



## Usage
* At first, please run `bash run.sh` for init and validation.
* Then you can use `./sha3` for command line interaction.



## Reference
* https://nvlpubs.nist.gov/nistpubs/FIPS/NIST.FIPS.202.pdf