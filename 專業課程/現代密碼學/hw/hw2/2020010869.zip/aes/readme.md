# AES-128-CBC



## Usage
* At first, please run `bash run.sh` for init and validation.
* Then you can use `./aes` for command line interaction.

