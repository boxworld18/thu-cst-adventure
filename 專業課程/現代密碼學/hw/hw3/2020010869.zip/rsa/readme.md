# RSA


## Usage
* At first, please run `bash run.sh` for init and validation.
* Then you can use `./rsa` for command line interaction.
